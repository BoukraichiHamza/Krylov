function [A,matname] = hor__131;
%
A = rdcoord('hor__131.mtx');
if nargout == 2
  matname = 'HOR131';
end
%
%end
